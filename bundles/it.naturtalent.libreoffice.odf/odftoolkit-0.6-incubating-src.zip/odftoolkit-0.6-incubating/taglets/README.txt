*************************************************************
* Taglets Java Library                                       *
*                                                           *
*************************************************************


About Taglets
-------------

This sub project defines some javadoc tags for ODFDOM. Most of users no need to care it.


License
--------

Apache License, Version 2.0. Please see file LICENSE.txt.

